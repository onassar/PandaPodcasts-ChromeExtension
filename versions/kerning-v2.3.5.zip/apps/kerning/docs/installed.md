## Kerning Cultures Chrome Extension Installed!

### Congratulations!
The [Kerning Cultures](https://kerningcultures.com/) Chrome Extension has been
installed, and you can now check out the newest episodes by simply clicking on
the Chrome Extension icon.
