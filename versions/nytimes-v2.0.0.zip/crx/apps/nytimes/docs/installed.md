## NYTimes Podcasts Chrome Extension Installed

### Congratulations!
The (unofficial and unauthorized) [New York Times](https://nytimes.com/)
Podcasts Chrome Extension has been installed, and you can now check out the
newest episodes from each of their podcasts by simply clicking on the Chrome
Extension icon.

### Disclosure
This Chrome Extension is not affiliated with, or supported by,
[The New York Times](https://nytimes.com/). Rather, it's an extension I built as
a fan of the podcasts, and as a way to keep up on new episodes.
