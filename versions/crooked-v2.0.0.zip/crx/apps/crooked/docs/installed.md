## Crooked Media Chrome Extension Installed

### Congratulations!
You're life has just changed, in the most modest &amp; insignificant way, for
the better.

The (unofficial and unauthorized) [Crooked Media](https://crooked.com/)
Chrome Extension has been installed, and you can now check out the newest
episodes from each of their podcasts by simply clicking on the Chrome Extension
icon.

### Disclosure
This Chrome Extension is not affiliated with, or supported by,
[Crooked Media](https://crooked.com/). Rather, it's an extension I built as a
fan of the podcasts, and as a way to keep up on new episodes.
